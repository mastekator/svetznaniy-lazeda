<?php
/**
 * Plugin Name: Lezada Addons
 * Plugin URI: https://lezadaa.thememove.com/
 * Description: A collection of shortcodes for Visual Composer. It was made for Lezada theme
 * Author: ThemeMove
 * Author URI: http://thememove.com
 * Version: 2.0
 * Text Domain: lezada-addons
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_theme = wp_get_theme();

if ( ! empty( $current_theme['Template'] ) ) {
	$current_theme = wp_get_theme( $current_theme['Template'] );
}

define( 'LEZADA_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
define( 'LEZADA_ADDONS_URL', plugin_dir_url( __FILE__ ) );
define( 'LEZADA_ADDONS_VERSION', '1.0' );
define( 'LEZADA_ADDONS_THEME_NAME', $current_theme['Name'] );
define( 'LEZADA_ADDONS_LIBS_URI', LEZADA_ADDONS_URL . '/assets/libs' );


/**
 * Class Lezada_Addons
 */
if ( ( $current_theme->name === 'Lezada' ) || ( $current_theme->name === 'Lezada Child' ) || ( $current_theme->name === 'Lezada Child Demo' ) ) {
	class Lezada_Addons
	{

		public function __construct()
		{
			$this->init();
			$this->includes();
		}

		/**
		 * Initialize
		 */
		public function init()
		{
			add_action('admin_notices', array($this, 'check_dependencies'));

			add_action('wp_enqueue_scripts', array($this, 'enqueue',));
			add_action('admin_enqueue_scripts', array($this, 'admin_css',), 10);

			add_action('init', function () {
				load_plugin_textdomain('lezada-addons', false, plugin_basename(dirname(__FILE__)) . '/languages');
			});
		}

		/**
		 * Load files
		 */
		public function includes()
		{
			include_once(LEZADA_ADDONS_DIR . 'includes/class-lezada-testimonial.php');

			if (defined('WPB_VC_VERSION')) {
				include_once(LEZADA_ADDONS_DIR . 'includes/class-lezada-vendor-woocommerce.php');
				include_once(LEZADA_ADDONS_DIR . 'includes/class-lezada-vc.php');
				include_once(LEZADA_ADDONS_DIR . 'includes/class-mailchimp.php');
			}

			include_once(LEZADA_ADDONS_DIR . 'includes/widgets/wph-widget-class.php');
			include_once(LEZADA_ADDONS_DIR . 'includes/widgets/widget-contact-info.php');
			include_once(LEZADA_ADDONS_DIR . 'includes/widgets/widget-instagram.php');

			include_once(LEZADA_ADDONS_DIR . 'includes/widgets/widget-social.php');

			include_once(LEZADA_ADDONS_DIR . 'includes/widgets/widget-recent-posts.php');


			if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
				include_once(LEZADA_ADDONS_DIR . 'includes/widgets/widget-layered-nav.php');
				include_once(LEZADA_ADDONS_DIR . 'includes/widgets/widget-sorting.php');
				include_once(LEZADA_ADDONS_DIR . 'includes/widgets/widget-price-filter.php');
				include_once(LEZADA_ADDONS_DIR . 'includes/class-video-product.php');
			}
		}

		/**
		 * Check plugin dependencies
		 * Check if Visual Composer plugin is installed
		 */
		public function check_dependencies()
		{
			if (!defined('WPB_VC_VERSION')) {
				$plugin_data = get_plugin_data(__FILE__);

				printf('<div class="notice notice-error"><p>%s</p></div>',
					sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.',
						'lezada-addons'),
						$plugin_data['Name']));
			}
		}

		/**
		 * Add admin css
		 *
		 * @since 1.0
		 */
		public function admin_css()
		{
			/*
             * Enqueue main JS
             */
			wp_enqueue_style('lezada-addons-admin',
				LEZADA_ADDONS_URL . 'assets/css/admin.css',
				array(),
				LEZADA_ADDONS_VERSION);
		}

		/**
		 * Enqueue scrips & styles.
		 *
		 * @access public
		 */
		public function enqueue()
		{
			wp_enqueue_script('lezada-shortcode-js',
				LEZADA_ADDONS_URL . 'assets/js/shortcodes.js',
				array('jquery'),
				LEZADA_ADDONS_VERSION,
				true);
		}

		/**
		 * Get option from Redux Framework
		 *
		 * @since 1.0
		 *
		 * @param string $option
		 *
		 * @return mixed
		 */
		public static function get_option($option = '')
		{

			global $lezada_options;

			return isset($lezada_options[$option]) ? $lezada_options[$option] : '';
		}
	}

	new Lezada_Addons();
}
