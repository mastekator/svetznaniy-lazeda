<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register portfolio support
 */
class Lezada_Testimonial {

	private $post_type = 'testimonial';
	private $taxonomy_type = 'testimonial-category';

	public function __construct() {
		$this->register_post_type();
		$this->register_taxonomy();
	}

	public function register_post_type() {

		if ( post_type_exists( $this->post_type ) ) {
			return;
		}

		register_post_type( $this->post_type,
			array(
				'labels'            => array(
					'name'               => esc_html__( 'Testimonials', 'lezada-addons' ),
					'singular_name'      => esc_html__( 'Testimonial', 'lezada-addons' ),
					'add_new'            => esc_html__( 'Add New', 'lezada-addons' ),
					'add_new_item'       => esc_html__( 'Add New Testimonial', 'lezada-addons' ),
					'edit_item'          => esc_html__( 'Edit Testimonial', 'lezada-addons' ),
					'new_item'           => esc_html__( 'New Testimonial', 'lezada-addons' ),
					'view_item'          => esc_html__( 'View Testimonial', 'lezada-addons' ),
					'search_items'       => esc_html__( 'Search Testimonials', 'lezada-addons' ),
					'not_found'          => esc_html__( 'No testimonials have been added yet', 'lezada-addons' ),
					'not_found_in_trash' => esc_html__( 'Nothing found in Trash', 'lezada-addons' ),
					'parent_item_colon'  => '',
				),
				'public'            => false,
				'has_archive'       => false,
				'show_ui'           => true,
				'show_in_menu'      => true,
				'show_in_nav_menus' => false,
				'menu_icon'         => 'dashicons-format-quote',
				'rewrite'           => false,
				'supports'          => array(
					'title',
					'editor',
					'custom-fields',
					'excerpt',
					'revisions',
				),
			) );
	}

	public function register_taxonomy() {

		register_taxonomy( $this->taxonomy_type,
			$this->post_type,
			array(
				'labels'            => esc_html__( 'Testimonial Categories', 'lezada-addons' ),
				'hierarchical'      => true,
				'public'            => false,
				'show_ui'           => true,
				'show_admin_column' => true,
				'show_in_nav_menus' => false,
				'rewrite'           => false,
				'query_var'         => true,
			) );
	}
}

new Lezada_Testimonial();
