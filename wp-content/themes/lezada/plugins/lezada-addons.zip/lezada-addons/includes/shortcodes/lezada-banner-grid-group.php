<?php
class WPBakeryShortCode_Lezada_Banner_Grid_Group extends WPBakeryShortCodesContainer {

}

// Banner Grid 5
vc_map( array(
	'name'                    => esc_html__( 'Banner Grid Group', 'lezada-addons' ),
	'description'             => esc_html__( 'Arrange multiple banners per row with unusual structure.', 'lezada-addons' ),
	'base'                    => 'lezada_banner_grid_group',
	'icon'                    => 'lezada-element-icon-banner-grid-group',
	'category'                => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'js_view'                 => 'VcColumnView',
	'content_element'         => true,
	'show_settings_on_create' => false,
	'as_parent'               => array( 'only' => 'lezada_banner, lezada_banner2, lezada_banner3, lezada_product_category_banner, rev_slider, rev_slider_vc' ),
	'params'                  => array(

		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Style', 'miimo' ),
			'param_name'  => 'style',
			'value'       => array(
				esc_html__( 'Group maximum 3 items', 'miimo' )              => 'group-3-items',
				esc_html__( 'Group maximum 5 items', 'miimo' )              => 'group-5-items',
			),
			'std'         => 'group-3-items',
			'description' => esc_html__( 'Choose style for banner.', 'miimo' ),
		),

		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_param( 'css' ),
	),
) );
