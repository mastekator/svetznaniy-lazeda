<?php

/**
 * ThemeMove Team Member Shortcode
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Portfolio_Navigation extends WPBakeryShortCode {

}

// Mapping shortcode.
vc_map( array(
	'name'     => esc_html__( 'Portfolio Navigation', 'lezada-addons' ),
	'base'     => 'lezada_portfolio_navigation',
	'icon'     => 'lezada-element-icon-portfolio-navigation',
	'category' => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'params'   => array(
		array(
			'type'        => 'checkbox',
			'heading'     => esc_html__( 'Same category?', 'lezada-addons' ),
			'description' => esc_html__( 'Check this option if you want to next/back in the same category', 'lezada-addons' ),
			'param_name'  => 'same_category',
			'admin_label' => true,
		),
		array(
			'type'        => 'checkbox',
			'heading'     => esc_html__( 'Archive custom link?', 'lezada-addons' ),
			'description' => esc_html__( 'Check this option if you want to add custom link for archive page', 'lezada-addons' ),
			'param_name'  => 'custom_archive',
			'admin_label' => true,
		),
		array(
			'type'        => 'vc_link',
			'heading'     => esc_html__( 'Custom archive link', 'lezada-addons' ),
			'param_name'  => 'custom_archive_link',
			'admin_label' => true,
			'dependency'  => array( 'element' => 'custom_archive', 'value' => array( 'true' ) ),
		),

		Lezada_VC::get_animation_field(),
		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_param( 'css' ),
	),
) );