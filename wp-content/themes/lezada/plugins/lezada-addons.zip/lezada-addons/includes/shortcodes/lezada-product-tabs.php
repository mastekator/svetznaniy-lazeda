<?php

/**
 * Lezada Product Tabs Shortcode
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Product_Tabs extends WPBakeryShortCode {

	public function __construct( $settings ) {
		parent::__construct( $settings );
		add_filter( 'lezada_shop_products_columns', array( $this, 'product_columns' ) );
		add_filter( 'lezada_product_loop_thumbnail_size', array( $this, 'image_size' ) );
	}

	public function product_columns() {

		$atts = $this->getAtts();

		return array(
			'xs' => 1,
			'sm' => 2,
			'md' => 3,
			'lg' => 4,
			'xl' => $atts['columns'],
		);
	}

	public function image_size() {

		$atts = $this->getAtts();

		if ( empty( $atts['img_size'] ) ) {
			$atts['img_size'] = 'woocommerce_thumbnail';
		}

		return isset( $atts['img_size'] ) ? Lezada_Helper::convert_image_size( $atts['img_size'] ) : 'woocommerce_thumbnail';
	}

	public function make_tab( $index, $tab ) {

		$atts = $this->getAtts();

		switch ( $tab ) {
			case 'featured_products':
				$filter = ( isset( $atts['filter_type'] ) && $atts['filter_type'] == 'ajax' ) ? 'featured_products' : '.featured';
				$name   = esc_html__( 'Popular', 'lezada-addons' );
				break;
			case 'sale_products':
				$filter = ( isset( $atts['filter_type'] ) && $atts['filter_type'] == 'ajax' ) ? 'sale_products' : '.sale';
				$name   = esc_html__( 'Sale', 'lezada-addons' );
				break;
			case 'best_selling_products':
				$filter = 'best_selling_products';
				$name   = esc_html__( 'Best Sellings', 'lezada-addons' );
				break;
			case 'top_rated_products':
				$filter = 'top_rated_products';
				$name   = esc_html__( 'Top Rated', 'lezada-addons' );
				break;
			case 'recent_products':
			default:
				$filter = ( isset( $atts['filter_type'] ) && $atts['filter_type'] == 'ajax' ) ? 'recent_products' : '.product';
				$name   = esc_html__( 'New', 'lezada-addons' );
				break;
		}

		return sprintf( '<li><a class="%s" href="#" data-filter="%s" data-page="1">%s</a></li>',
			( isset( $atts['filter_type'] ) && $atts['filter_type'] == 'ajax' && ! $index ) ? 'active' : '',
			$filter,
			$name );
	}
}

// Mapping shortcode.
vc_map( array(
	'name'        => esc_html__( 'Product Tabs', 'lezada-addons' ),
	'base'        => 'lezada_product_tabs',
	'icon'        => 'lezada-element-icon-product-tabs',
	'category'    => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'description' => esc_html__( 'Product grid grouped by tabs', 'lezada-addons' ),
	'params'      => array(

		array(
			'heading'     => esc_html__( 'Tabs', 'lezada-addons' ),
			'description' => esc_html__( 'Select how to group products in tabs', 'lezada-addons' ),
			'param_name'  => 'filter',
			'type'        => 'dropdown',
			'admin_label' => true,
			'value'       => array(
				esc_html__( 'Group by category', 'lezada-addons' ) => 'category',
				esc_html__( 'Group by feature', 'lezada-addons' )  => 'group',
			),
		),

		array(
			'heading'     => esc_html__( 'Tabs Effect', 'lezada-addons' ),
			'description' => esc_html__( 'Select the way tabs load products', 'lezada-addons' ),
			'param_name'  => 'filter_type',
			'type'        => 'dropdown',
			'value'       => array(
				esc_html__( 'Filter', 'lezada-addons' )    => 'filter',
				esc_html__( 'Ajax Load', 'lezada-addons' ) => 'ajax',
			),
		),

		array(
			'heading'    => esc_html__( 'Tabs Alignment', 'lezada-addons' ),
			'param_name' => 'align',
			'type'       => 'dropdown',
			'value'      => array(
				esc_html__( 'Left', 'lezada-addons' )   => 'left',
				esc_html__( 'Center', 'lezada-addons' ) => 'center',
				esc_html__( 'Right', 'lezada-addons' )  => 'right',
			),
		),

		Lezada_VC::get_param( 'product_cat_autocomplete',
			'',
			array(
				'element' => 'filter',
				'value'   => array( 'category' ),
			) ),

		array(
			'type'        => 'chosen',
			'heading'     => esc_html__( 'Tab', 'lezada-addons' ),
			'description' => esc_html__( 'Select which tabs you want to show', 'lezada-addons' ),
			'param_name'  => 'tabs',
			'options'     => array(
				'multiple' => true,
				'values'   => array(
					array( 'label' => esc_html__( 'Featured Products', 'lezada-addons' ), 'value' => 'featured_products' ),
					array( 'label' => esc_html__( 'New Products', 'lezada-addons' ), 'value' => 'recent_products' ),
					array( 'label' => esc_html__( 'On Sale Products', 'lezada-addons' ), 'value' => 'sale_products' ),
					array(
						'label' => esc_html__( 'Best-Selling Products (only Ajax Load)', 'lezada-addons' ),
						'value' => 'best_selling_products',
					),
					array(
						'label' => esc_html__( 'Top Rated Products (only Ajax Load)', 'lezada-addons' ),
						'value' => 'top_rated_products',
					),
				),
			),
			'dependency'  => array( 'element' => 'filter', 'value' => array( 'group' ) ),
		),

		array(
			'type'       => 'dropdown',
			'param_name' => 'product_style',
			'heading'    => esc_html__( 'Select product item style', 'lezada-addons' ),
			'value'      => array(
				esc_html__( 'Default', 'lezada-addons' )          => 'default',
				esc_html__( 'Button Hover', 'lezada-addons' )     => 'button-hover',
				esc_html__( 'Button Hover Alt', 'lezada-addons' ) => 'button-hover-alt',
			),
		),

		array(
			'type'        => 'number',
			'param_name'  => 'number',
			'heading'     => esc_html__( 'Number', 'lezada-addons' ),
			'description' => esc_html__( 'Total number of products will be display in single tab (-1 is all, limited to 1000)',
				'lezada-addons' ),
			'value'       => 12,
			'max'         => 1000,
			'min'         => - 1,
		),

		Lezada_VC::get_param( 'columns' ),

		array(
			'type'       => 'autocomplete',
			'heading'    => esc_html__( 'Exclude products', 'lezada-addons' ),
			'param_name' => 'exclude',
			'settings'   => array(
				'multiple' => true,
				'sortable' => true,
			),
		),

		array(
			'type'        => 'checkbox',
			'param_name'  => 'include_children',
			'description' => esc_html__( 'Whether or not to include children categories', 'lezada-addons' ),
			'value'       => array( esc_html__( 'Include children', 'lezada-addons' ) => 'yes' ),
			'std'         => 'yes',
			'dependency'  => array( 'element' => 'data_source', 'value' => array( 'category' ) ),
		),

		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'Image size', 'lezada-addons' ),
			'param_name'  => 'img_size',
			'value'       => 'woocommerce_thumbnail',
			'description' => esc_html__( 'Enter image size . Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme . Alternatively enter image size in pixels: 200x100( Width x Height). Leave empty to use "woocommerce_thumbnail" size . ',
				'lezada-addons' ),
		),

		array(
			'type'       => 'dropdown',
			'param_name' => 'pagination_type',
			'heading'    => esc_html__( 'Pagination type', 'lezada-addons' ),
			'value'      => array(
				esc_html__( 'None', 'lezada-addons' )             => '',
				esc_html__( 'Load More Button', 'lezada-addons' ) => 'more-btn',
				esc_html__( 'Infinite Scroll', 'lezada-addons' )  => 'infinite',
			),
			'dependency' => array(
				'element'            => 'data_source',
				'value_not_equal_to' => array( 'products' ),
			),
		),
		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_animation_field(),
		// Data settings.
		Lezada_VC::get_param( 'order_product', esc_html__( 'Data Settings', 'lezada-addons' ) ),
		Lezada_VC::get_param( 'order_way', esc_html__( 'Data Settings', 'lezada-addons' ) ),
		Lezada_VC::get_param( 'css' ),
	),
) );


//Filters For autocomplete param:
//For suggestion: vc_autocomplete_[shortcode_name]_[param_name]_callback
add_filter( 'vc_autocomplete_lezada_product_tabs_exclude_callback',
	array(
		'Lezada_VC',
		'product_id_callback',
	),
	10,
	1 );

add_filter( 'vc_autocomplete_lezada_product_tabs_exclude_render',
	array(
		'Lezada_VC',
		'product_id_render',
	),
	10,
	1 );
