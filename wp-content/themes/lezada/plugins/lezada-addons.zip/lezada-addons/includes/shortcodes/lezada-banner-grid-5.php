<?php

/**
 * ThemeMove Banner Grid 5 Shortcode
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Banner_Grid_5 extends WPBakeryShortCodesContainer {

}

// Banner Grid 5
vc_map( array(
	'name'                    => esc_html__( 'Banner Grid 5', 'lezada-addons' ),
	'description'             => esc_html__( 'Group maximum 5 banners into 2 columns', 'lezada-addons' ),
	'base'                    => 'lezada_banner_grid_5',
	'icon'                    => 'lezada-element-icon-banner-grid-5',
	'category'                => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'js_view'                 => 'VcColumnView',
	'content_element'         => true,
	'show_settings_on_create' => false,
	'as_parent'               => array( 'only' => 'lezada_banner, lezada_banner2, lezada_banner3, lezada_product_category_banner, rev_slider, rev_slider_vc' ),
	'params'                  => array(

		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_param( 'css' ),
	),
) );
