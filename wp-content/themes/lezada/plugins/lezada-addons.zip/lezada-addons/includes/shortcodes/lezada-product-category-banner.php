<?php

/**
 * ThemeMove Category Banner Shortcode
 *
 * @version 1.0
 * @package lezada
 */
class WPBakeryShortCode_Lezada_Product_Category_Banner extends WPBakeryShortCode {

	public function shortcode_css( $css_id ) {

		$atts  = vc_map_get_attributes( $this->getShortcode(), $this->getAtts() );
		$cssID = '#' . $css_id;
		$css   = '';

		$font_size   = $atts['font_size'] ? $atts['font_size'] : 18;
		$color_name  = $atts['color_name'] ? $atts['color_name'] : SECONDARY_COLOR;
		$color_count = $atts['color_count'] ? $atts['color_count'] : '#ababab';

		$css .= $cssID . ' .category-name{';
		$css .= 'color:' . $color_name . ';';
		$css .= 'font-size:' . $font_size . 'px;}';
		$css .= $cssID . ' .product-count{color:' . $color_count . '}';

		global $lezada_shortcode_css;
		$lezada_shortcode_css .= Lezada_VC::text2line( $css );
	}

	/**
	 *
	 * Custom title in backend, show image instead of icon
	 *
	 * @param $param
	 * @param $value
	 *
	 * @return string
	 */
	public function singleParamHtmlHolder( $param, $value ) {

		$output = '';

		$param_name = isset( $param['param_name'] ) ? $param['param_name'] : '';
		$type       = isset( $param['type'] ) ? $param['type'] : '';
		$class      = isset( $param['class'] ) ? $param['class'] : '';

		if ( 'attach_image' === $param['type'] && 'image' === $param_name ) {
			$output       .= '<input type="hidden" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="' . $value . '" />';
			$element_icon = $this->settings( 'icon' );
			$img          = wpb_getImageBySize( array(
				'attach_id'  => (int) preg_replace( '/[^\d]/', '', $value ),
				'thumb_size' => 'thumbnail',
				'class'      => 'attachment-thumbnail vc_general vc_element-icon tm-element-icon-none',
			) );
			$this->setSettings( 'logo',
				( $img ? $img['thumbnail'] : '<img width="150" height="150" src="' . vc_asset_url( 'vc/blank.gif' ) . '" class="attachment-thumbnail vc_general vc_element-icon lezada-element-icon-banner"  data-name="' . $param_name . '" alt="" title="" style="display: none;" />' ) . '<span class="no_image_image vc_element-icon' . ( ! empty( $element_icon ) ? ' ' . $element_icon : '' ) . ( $img && ! empty( $img['p_img_large'][0] ) ? ' image-exists' : '' ) . '" /><a href="#" class="column_edit_trigger' . ( $img && ! empty( $img['p_img_large'][0] ) ? ' image-exists' : '' ) . '">' . __( 'Add image',
					'lezada-addons' ) . '</a>' );
			$output .= $this->outputCustomTitle( $this->settings['name'] );
		} elseif ( ! empty( $param['holder'] ) ) {
			if ( 'input' === $param['holder'] ) {
				$output .= '<' . $param['holder'] . ' readonly="true" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="' . $value . '">';
			} elseif ( in_array( $param['holder'],
				array(
					'img',
					'iframe',
				) ) ) {
				$output .= '<' . $param['holder'] . ' class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" src="' . $value . '">';
			} elseif ( 'hidden' !== $param['holder'] ) {
				$output .= '<' . $param['holder'] . ' class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '">' . $value . '</' . $param['holder'] . '>';
			}
		}

		if ( ! empty( $param['admin_label'] ) && true === $param['admin_label'] ) {
			$output .= '<span class="vc_admin_label admin_label_' . $param['param_name'] . ( empty( $value ) ? ' hidden-label' : '' ) . '"><label>' . $param['heading'] . '</label>: ' . $value . '</span>';
		}

		return $output;
	}

	protected function outputTitle( $title ) {
		return '';
	}

	protected function outputCustomTitle( $title ) {
		return '<h4 class="wpb_element_title">' . $title . ' ' . $this->settings( 'logo' ) . '</h4>';
	}
}

vc_map( array(
	'name'        => esc_html__( 'Product Category Banner', 'lezada-addons' ),
	'description' => esc_html__( 'Simple banner for single product category', 'lezada-addons' ),
	'base'        => 'lezada_product_category_banner',
	'icon'        => 'lezada-element-icon-product-category-banner',
	'category'    => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'params'      => array(

		// General
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Image Source', 'lezada-addons' ),
			'param_name'  => 'source',
			'value'       => array(
				esc_html__( 'Media library', 'lezada-addons' ) => 'media_library',
				esc_html__( 'External link', 'lezada-addons' ) => 'external_link',
			),
			'std'         => 'media_library',
			'description' => esc_html__( 'Select image source.', 'lezada-addons' ),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => esc_html__( 'Banner Image', 'lezada-addons' ),
			'param_name'  => 'image',
			'value'       => '',
			'description' => esc_html__( 'Select an image from media library.', 'lezada-addons' ),
			'dependency'  => array(
				'element' => 'source',
				'value'   => 'media_library',
			),
		),
		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'External Link', 'lezada-addons' ),
			'param_name'  => 'custom_src',
			'description' => esc_html__( 'Select external link.', 'lezada-addons' ),
			'dependency'  => array(
				'element' => 'source',
				'value'   => 'external_link',
			),
		),
		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'Image Size (Optional)', 'lezada-addons' ),
			'param_name'  => 'img_size',
			'value'       => 'full',
			'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).',
				'lezada-addons' ),
			'dependency'  => array(
				'element' => 'source',
				'value'   => array( 'media_library' ),
			),
		),
		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'Image Size (Optional)', 'lezada-addons' ),
			'param_name'  => 'external_img_size',
			'value'       => '',
			'description' => esc_html__( 'Enter image size in pixels. Example: 200x100 (Width x Height).',
				'lezada-addons' ),
			'dependency'  => array(
				'element' => 'source',
				'value'   => 'external_link',
			),
		),
		Lezada_VC::get_param( 'product_cat_dropdown' ),
		array(
			'type'        => 'number',
			'heading'     => esc_html__( 'Font size', 'lezada-addons' ),
			'description' => esc_html__( 'Font size of the product name.', 'lezada-addons' ),
			'param_name'  => 'font_size',
			'value'       => 18,
			'min'         => 16,
			'max'         => 50,
			'step'        => 1,
			'suffix'      => 'px',
		),
		array(
			'heading'    => esc_html__( 'Product Count Visibility', 'lezada-addons' ),
			'type'       => 'dropdown',
			'param_name' => 'product_count_visibility',
			'value'      => array(
				esc_html__( 'Always visible', 'lezada-addons' ) => 'always',
				esc_html__( 'Hidden', 'lezada-addons' )         => 'hidden',
			),
		),
		array(
			'heading'    => esc_html__( 'Text position', 'lezada-addons' ),
			'type'       => 'dropdown',
			'param_name' => 'style',
			'value'      => array(
				esc_html__( 'Text Above', 'lezada-addons' )  => 'above',
				esc_html__( 'Text Below', 'lezada-addons' )  => 'below',
				esc_html__( 'Text Inside', 'lezada-addons' ) => 'inside',
			),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'hover_with_background',
			'value'      => array( esc_html__( 'Hover with white background', 'lezada-addons' ) => 'yes' ),
			'dependency' => array(
				'element' => 'style',
				'value'   => 'inside',
			),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'open_new_tab',
			'value'      => array( esc_html__( 'Open link in a new tab', 'lezada-addons' ) => 'yes' ),
		),
		Lezada_VC::get_param( 'el_class' ),

		// Color
		array(
			'group'      => esc_html__( 'Color', 'lezada-addons' ),
			'type'       => 'colorpicker',
			'heading'    => esc_html__( 'Category Name', 'lezada-addons' ),
			'param_name' => 'color_name',
			'value'      => '#333333',
		),
		array(
			'group'      => esc_html__( 'Color', 'lezada-addons' ),
			'type'       => 'colorpicker',
			'heading'    => esc_html__( 'Product Count', 'lezada-addons' ),
			'param_name' => 'color_count',
			'value'      => '#333333',
		),

		// Animation
		array(
			'group'       => esc_html__( 'Animation', 'lezada-addons' ),
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Banner Hover Effect', 'lezada-addons' ),
			'admin_label' => true,
			'param_name'  => 'hover_style',
			'value'       => array(
				esc_html__( 'none', 'lezada-addons' )            => '',
				esc_html__( 'Zoom in', 'lezada-addons' )         => 'zoom-in',
				esc_html__( 'Border and zoom', 'lezada-addons' ) => 'border-zoom',
				esc_html__( 'Blur', 'lezada-addons' )            => 'blur',
				esc_html__( 'Gray scale', 'lezada-addons' )      => 'grayscale',
				esc_html__( 'White Overlay', 'lezada-addons' )   => 'white-overlay',
				esc_html__( 'Black Overlay', 'lezada-addons' )   => 'black-overlay',
			),
			'std'         => 'zoom-in',
			'description' => esc_html__( 'Select animation style for banner when mouse over. Note: Some styles only work in modern browsers',
				'lezada-addons' ),
		),
		array(
			'group'       => esc_html__( 'Animation', 'lezada-addons' ),
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'CSS Animation', 'lezada-addons' ),
			'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).',
				'lezada-addons' ),
			'param_name'  => 'animation',
			'value'       => array(
				esc_html__( 'None', 'lezada-addons' )             => '',
				esc_html__( 'Fade In', 'lezada-addons' )          => 'fade-in',
				esc_html__( 'Move Up', 'lezada-addons' )          => 'move-up',
				esc_html__( 'Move Down', 'lezada-addons' )        => 'move-down',
				esc_html__( 'Move Left', 'lezada-addons' )        => 'move-left',
				esc_html__( 'Move Right', 'lezada-addons' )       => 'move-right',
				esc_html__( 'Scale Up', 'lezada-addons' )         => 'scale-up',
				esc_html__( 'Fall Perspective', 'lezada-addons' ) => 'fall-perspective',
				esc_html__( 'Fly', 'lezada-addons' )              => 'fly',
				esc_html__( 'Flip', 'lezada-addons' )             => 'flip',
				esc_html__( 'Helix', 'lezada-addons' )            => 'helix',
				esc_html__( 'Pop Up', 'lezada-addons' )           => 'pop-up',
			),
			'std'         => 'scale-up',
		),
		Lezada_VC::get_param( 'css' ),
	),
) );
