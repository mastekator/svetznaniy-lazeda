<?php

/*
 * Lezada Brands Grid
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Brands_Grid extends WPBakeryShortCode {
}

// Mapping shortcode.
vc_map( array(
	'name'        => __( 'Brand\'s Image Grid', 'lezada-addons' ),
	'base'        => 'lezada_brands_grid',
	'icon'        => 'lezada-element-icon-brand-image-grid',
	'category'    => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'description' => esc_html__( 'Show brands in a grid.', 'lezada-addons' ),
	'params'      => array(
		array(
			'type'       => 'chosen',
			'heading'    => esc_html__( 'Select Brand', 'lezada-addons' ),
			'param_name' => 'brand_slugs',
			'options'    => array(
				'type'  => 'taxonomy',
				'get'   => 'product_brand',
				'field' => 'slug',
			)
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'hide_empty',
			'std'        => 'yes',
			'value'      => array( esc_html__( 'Hide empty brands', 'lezada-addons' ) => 'yes' ),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'display_featured',
			'value'      => array( esc_html__( 'Display only feature brands', 'lezada-addons' ) => 'yes' ),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'show_title',
			'value'      => array( esc_html__( 'Show brand\'s title', 'lezada-addons' ) => 'yes' ),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'new_tab',
			'value'      => array( esc_html__( 'Open link in a new tab', 'lezada-addons' ) => 'yes' ),
		),
		Lezada_VC::get_param( 'columns' ),
		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_param( 'css' ),
		Lezada_VC::get_animation_field(),
	)
) );
